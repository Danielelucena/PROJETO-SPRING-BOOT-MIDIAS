package mediatype.demo.controller;

import mediatype.demo.model.MediaItem;
import mediatype.demo.repository.MediaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Controller
public class MediaController {
    @Autowired
    private MediaRepository mediaRepository;
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("items", mediaRepository.findAll());  return "index";
    }
    @PostMapping(value = "/upload", consumes =
            MediaType.MULTIPART_FORM_DATA_VALUE)
    public String handleUpload(@RequestParam("file") MultipartFile file) throws IOException {
        String uploadDir = "src/main/resources/static/uploads/";
        Files.copy(file.getInputStream(), Paths.get(uploadDir +
                file.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
        MediaItem item = new MediaItem();
        item.setFilename(file.getOriginalFilename());
        item.setMediaType(file.getContentType());
        mediaRepository.save(item);
        return "redirect:/";
    }
    @GetMapping("/media/{filename}")
    public ResponseEntity<Resource> serveFile(@PathVariable String filename)  throws IOException {
        Path file = Paths.get("src/main/resources/static/uploads/" + filename);  String contentType = Files.probeContentType(file);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))  .body(new UrlResource(file.toUri()));
    }
}

