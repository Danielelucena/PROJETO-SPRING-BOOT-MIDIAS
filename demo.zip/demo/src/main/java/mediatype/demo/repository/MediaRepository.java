package mediatype.demo.repository;

import mediatype.demo.model.MediaItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MediaRepository extends JpaRepository<MediaItem, Long> { }

