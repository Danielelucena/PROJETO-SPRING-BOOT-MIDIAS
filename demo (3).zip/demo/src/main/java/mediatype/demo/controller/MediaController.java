package mediatype.demo.controller;

import mediatype.demo.model.MediaItem;
import mediatype.demo.repository.MediaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.http.HttpHeaders;

@Controller
public class MediaController {

    @Autowired
    private MediaRepository mediaRepository;

    private final Path rootLocation = Paths.get("uploads"); // Diretório para armazenar os arquivos

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("items", mediaRepository.findAll()); // Passando os arquivos do banco para o template
        return "index";
    }

    @PostMapping(value = "/upload", consumes = "multipart/form-data")
    public String handleUpload(@RequestParam("file") MultipartFile file) throws IOException {
        // Verificar se o diretório de upload existe, senão criar
        if (!Files.exists(rootLocation)) {
            Files.createDirectories(rootLocation);
        }

        String filename = file.getOriginalFilename();
        String mediaType = file.getContentType();

        // Salvar o arquivo no diretório "uploads"
        Files.copy(file.getInputStream(), rootLocation.resolve(filename), StandardCopyOption.REPLACE_EXISTING);

        // Salvar informações sobre o arquivo no banco de dados
        MediaItem item = new MediaItem();
        item.setFilename(filename);
        item.setMediaType(mediaType);  // Tipo MIME do arquivo
        mediaRepository.save(item);

        return "redirect:/";
    }

    @GetMapping("/media/{filename}")
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) throws IOException {
        Path file = rootLocation.resolve(filename);
        Resource resource = new UrlResource(file.toUri());

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(resource);
    }
}
