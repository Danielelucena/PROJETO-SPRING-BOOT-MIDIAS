package mediatype.demo.config;

public class H2Config {
}
